package com.example;

import java.util.Scanner;

public class Calculator {
	
	

	  public static void main(String[] args) {

	    char operator;
	    
	    int number1=0, number2,number3, number4 = 0,result;
	    
	    String a1,a2,a3;

	    
	    
	    
	    Scanner input = new Scanner(System.in);

	  


	    System.out.println("Enter first number");
	    a1 = input.next();
	    
	    try {
            
           number1= Integer.parseInt(a1);
            System.out.println(
            		number1 + " is a valid integer number");
            System.out.println("Choose an operator: +, -, *, or /");
    	    operator = input.next().charAt(0);
    	    
    	    System.out.println("Enter two number");
    	    a2 = input.next();
    	    
    	    try {
                
               number2= Integer.parseInt(a2);
                System.out.println(
                		number2 + " is a valid integer number");
                
                switch (operator) {

      	     
      	      case '+':
      	    	  number4 = number1 + number2  ;
      	        System.out.println(number1 + " + " + number2 + " = " + number4);
      	        break;

      	      
      	      case '-':
      	    	  number4 = number1 - number2 ;
      	        System.out.println(number1 + " - " + number2 + " = " + number4);
      	        break;

      	     
      	      case '*':
      	    	  number4 = number1 * number2 ;
      	        System.out.println(number1 + " * " + number2 + " = " + number4);
      	        break;

      	    
      	      case '/':
      	    	  number4 = number1 / number2;
      	        System.out.println(number1 + " / " + number2 +  " = " + number4);
      	        break;

      	       default:
      	        System.out.println("Invalid operator!");
      	        break;
      	    }
                
                System.out.println("Choose an operator: +, -, *, or /");
        	    operator = input.next().charAt(0);
        	    
        	    System.out.println("Enter third  number");
        	    a3 = input.next();
        	    try {
                   
                   number3= Integer.parseInt(a3);
                    System.out.println(
                    		number3 + " is a valid integer number");
                    switch (operator) {

          	      case '+':
          	        result =  number4 + number3;
          	        System.out.println( number4 + " + " + number3 +" = " + result);
          	        break;

          	      case '-':
          	        result = number4 - number3;
          	        System.out.println( number4 +" - " + number3 + " = " + result);
          	        break;

          	      case '*':
          	        result = number4 * number3;
          	        System.out.println( number4 + " * " + number3 +" = " + result);
          	        break;

          	      case '/':
          	        result =  number4/ number3;
          	        System.out.println( number4 + " / " + number3 + " = " + result);
          	        break;

          	      default:
          	        System.out.println("Invalid operator!");
          	        break;
          	    }
          	    
                
                }
                catch (NumberFormatException e) {
                    System.out.println(
                        a3 + " Only integer is allow"+ e);
                }
        	    
      	   
            
            }
            catch (NumberFormatException e) {
                System.out.println(
                    a2 +" Only integer is allow"+ e);
            }
        
        }
        catch (NumberFormatException e) {
            System.out.println(
                a1 + " Only integer is allow"+e);
        }
	    


	
	    
	    
	   
	    
	   
	    
	   
	    
	    
	    

	    input.close();
	  }
	}


